# Day 2 – File Handling, JSON, NumPy & Pandas

**Name:** Syed M Qasim Bukhari  
**Repository:** https://github.com/qasim-codes784/MLB-Internship

> **Note on the "What I learned" sections:** they are a starting draft. Reword them in your own
> words and be ready to explain the code to your mentor.

## 1. Day 2 Learning Objectives
- Read, write and append text files safely with `with open(...)` and the `r`, `w`, `a` modes.
- Store and load structured data with JSON.
- Work with NumPy arrays (indexing, maths, reshaping).
- Load and analyse datasets with Pandas.
- Build an application whose data **survives closing the program**.

## 2. What I Learned About File Handling
- `open(path, mode, encoding="utf-8")` returns a file object. `"r"` reads, `"w"` writes (and **erases** existing content), `"a"` adds to the end.
- `with open(...) as file:` closes the file automatically, even if an error happens.
- A file can be looped over line by line, which is how I counted lines.
- `FileNotFoundError`, `PermissionError` and `OSError` can be caught with `try/except`.
- `pathlib.Path` builds file paths that work on any operating system.

## 3. What I Learned About JSON
- JSON is a text format that looks like Python dictionaries and lists.
- `json.dumps` / `json.loads` convert to / from a **string**; `json.dump` / `json.load` convert to / from a **file**.
- `None` becomes `null`, `True` becomes `true`.
- A broken or missing JSON file must be handled with `try/except json.JSONDecodeError`, not ignored.

## 4. What I Learned About NumPy
- Arrays hold one data type and support fast element-wise maths (`a + b`, `a * 2`).
- `shape`, `ndim`, `size`, `dtype` describe an array.
- Slicing `a[1:4]` excludes the end index; `m[:, 1]` selects a column.
- `sum`, `mean`, `min`, `max` work on whole arrays or along an `axis`.
- `reshape` only works if the element count stays the same (12 → 3×4 works, 12 → 5×3 fails).

## 5. What I Learned About Pandas
- A **Series** is one labelled column; a **DataFrame** is a table.
- `read_csv`, `head`, `tail`, `info`, `describe`, `shape` to inspect data.
- `df["col"]`, `df.loc[...]` (labels), `df.iloc[...]` (positions) to select.
- `df[df["maths"] >= 80]` filters rows; `isnull().sum()` counts missing values.
- Look at missing values **before** deciding to drop or fill them.

## 6. How File Handling and JSON Work Together
File handling is *where* data lives (a file on disk); JSON is *how* it is written (a structure that maps
directly to Python dicts/lists). `storage.py` uses `open()` to reach the file and `json.dump/json.load` to turn the
list of student dictionaries into text and back. That is what makes saving automatic.

## 7. The Upgraded System – Student Record Management v2
Folder: `Student_Record_Management/`

| File | Job |
|---|---|
| `main.py` | Menu and user interaction |
| `student_manager.py` | Add / search / update / delete / statistics logic, saves after every change |
| `storage.py` | JSON load/save, backup, CSV export, corrupt-file protection |
| `validators.py` | Input rules (same as Day 1: roll 1–999999, name letters only, age 5–100) |
| `import_day1_records.py` | Optional: import old students from a CSV |
| `data/students.json` | The permanent records |
| `data/students_backup.json` | Backup copy |

**Features:** add, view, search by roll number, search by name, update, delete (asks you to type `YES`),
total count, statistics, JSON backup, CSV export, duplicate roll-number prevention, automatic save and load,
handling of missing / empty / malformed JSON (a broken file is copied aside, never destroyed).

**Same as Day 1:** the unique ID is still `roll_no`, with `name`, `age`, `course`. **New and optional:** `subject` and `marks`
(leave blank to skip).

## 8. How Day 1 Student Records Were Transferred
**They were not, and could not be.** The Day 1 program kept students in a Python list in memory only
(`students = []`) and never saved them, so anything entered while it ran disappeared when it closed. There was no file to recover from.

So `students.json` starts as an **empty list** (`[]`). No fake records were created. To bring old students in:
1. Type them into a CSV with the header `roll_no,name,age,course`.
2. Run `python Student_Record_Management/import_day1_records.py my_old_students.csv`.
   It backs up first and skips duplicates and invalid rows. Or just use menu option 1.

The Day 1 files were not modified (verified by checksum before and after the work).

## 9. Student Performance Analysis
Folder: `Student_Performance_Analysis/` – uses Pandas and NumPy.

`students.csv` is **SAMPLE data I did not take from real students**, with two blank marks left in on purpose. Day 1 students had no marks, so none were invented for them.

It loads the CSV, explores it, finds missing values, calculates per-student totals and averages with NumPy
(`nansum`/`nanmean` ignore missing marks instead of faking them), average per subject, highest and lowest, top 5,
below-average students, pass/fail (pass mark = average ≥ 50), a filter (maths ≥ 80), and averages by course.
Outputs: `outputs/students_processed.csv` and `outputs/analysis_summary.csv`.

**Insights from the sample run:** 12 students; subject averages were maths 65.67, science 67.36, english 70.09; top student averaged 94.33;
5 students were below the overall average (67.51); 10 passed and 2 failed. Two students had a missing mark, so their
averages use only the marks they have. These come from *sample* data, so they say nothing about real students.

## 10. Installation (Windows)
```powershell
cd Day2
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
```
If activation is blocked, run `Set-ExecutionPolicy -Scope Process RemoteSigned` first.

## 11. How to Run
| What | Command |
|---|---|
| Menu for everything | `python main.py` |
| Student system v2 | `python Student_Record_Management/main.py` |
| Performance analysis | `python Student_Performance_Analysis/main.py` |
| Lessons | `python lessons/01_file_handling.py` (also `02_json_basics`, `03_numpy_fundamentals`, `04_pandas_basics`) |
| Practice | `python practice/01_file_handling_exercises.py` (also `02`, `03`, `04`) |
| Tests | `python -m unittest discover -s tests -v` |

## 12. Folder Structure
```text
Day2/
├── README.md
├── requirements.txt
├── main.py
├── .gitignore
├── lessons/        01_file_handling.py  02_json_basics.py  03_numpy_fundamentals.py  04_pandas_basics.py
├── practice/       01_..._exercises.py … 04_..._exercises.py
├── Student_Record_Management/
│   ├── main.py  student_manager.py  storage.py  validators.py  import_day1_records.py
│   └── data/       students.json  students_backup.json
├── Student_Performance_Analysis/   main.py  students.csv
├── outputs/        students_processed.csv  analysis_summary.csv
└── tests/          test_student_manager.py
```

## 13. Challenges and Solutions
| Challenge | Solution |
|---|---|
| Day 1 data lived only in memory | Added JSON persistence; honest empty start plus an import script |
| A crash while saving could corrupt the file | Write to a temp file, then replace the real file |
| A corrupted JSON file could crash the program or lose data | Copy it aside as `students_corrupt_<time>.json` and start empty |
| Accidental deletion | Typed `YES` confirmation plus an automatic backup first |
| Missing marks in the dataset | Detected them, used `nanmean`, never invented values |
| A test showed `update_student(roll_no=...)` clashed with the method's own `roll_no` parameter | Renamed the parameter to `roll_number` |

## 14. Testing Status
`python -m unittest discover -s tests -v` → **19 tests, all OK** (tested on Python 3.12, NumPy 2.5.4, pandas 3.0.6).
Tests cover add, search, update, delete, duplicate IDs, persistence, malformed/empty/missing files, UTF-8, CSV export, import and validators,
using temporary folders only. All lessons, practice files, the analysis and the menu were also run, including closing and reopening the program.

## 15. Known Limitations
- Tested on Linux; Windows commands follow standard Python behaviour but were not run on Windows.
- Names accept letters and spaces only (a Day 1 rule), so `O'Brien` is rejected.
- No login or multi-user safety: one program at a time should use the JSON file.

## 16. GitHub Commands
Copy the `Day2` folder into your local `MLB-Internship` repository folder, then:
```powershell
cd MLB-Internship
git status
git add Day2
git commit -m "Add Day 2: file handling, JSON, NumPy, Pandas, persistent student system"
git push origin main
```
If your branch is not `main`, check with `git branch`. If `.gitignore` already exists at the repo root, that's fine.
