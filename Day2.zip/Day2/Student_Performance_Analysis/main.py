"""
Student Performance Analysis (Pandas + NumPy)

Run from the Day2 folder:   python Student_Performance_Analysis/main.py
Reads students.csv, explores it, and writes two files into Day2/outputs/.

NOTE: students.csv is SAMPLE data. My Day 1 students had no marks.
"""
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
OUTPUT_DIR = HERE.parent / "outputs"
SUBJECTS = ["maths", "science", "english"]
PASS_MARK = 50  # a student passes if their average is at least this


def load_data(path=HERE / "students.csv"):
    # comment="#" makes pandas ignore the explanatory lines starting with #
    return pd.read_csv(path, comment="#")


def explore(df):
    print("=== First 5 rows ===")
    print(df.head())
    print("\n=== Last 5 rows ===")
    print(df.tail())
    print("\n=== Info ===")
    df.info()
    print("\n=== Summary statistics ===")
    print(df[SUBJECTS].describe().round(2))
    print("\nTotal students:", len(df))


def missing_report(df):
    print("\n=== Missing values per column ===")
    missing = df.isnull().sum()
    print(missing)
    for _, row in df[df[SUBJECTS].isnull().any(axis=1)].iterrows():
        print(f"  Roll {row['roll_no']} ({row['name']}) is missing some marks")
    return missing


def add_calculations(df):
    """Return a cleaned copy with total and average columns.

    Missing marks are NOT filled with fake numbers. NumPy's nanmean simply
    ignores them, so a student's average uses only the marks they have.
    """
    result = df.copy()
    marks = result[SUBJECTS].to_numpy(dtype=float)       # DataFrame -> NumPy array
    result["total"] = np.nansum(marks, axis=1)            # sum, ignoring NaN
    result["average"] = np.nanmean(marks, axis=1).round(2)
    result["status"] = np.where(result["average"] >= PASS_MARK, "Pass", "Fail")
    return result


def analyse(df):
    print("\n=== Average marks per subject ===")
    subject_avg = df[SUBJECTS].mean().round(2)  # pandas skips NaN automatically
    print(subject_avg)

    print("\n=== Highest and lowest student averages ===")
    best = df.loc[df["average"].idxmax()]
    worst = df.loc[df["average"].idxmin()]
    print(f"Highest: {best['name']} ({best['average']})")
    print(f"Lowest : {worst['name']} ({worst['average']})")

    print("\n=== Top 5 students ===")
    print(df.nlargest(5, "average")[["roll_no", "name", "average"]].to_string(index=False))

    overall = df["average"].mean()
    print(f"\n=== Students below the overall average ({overall:.2f}) ===")
    below = df[df["average"] < overall]
    print(below[["roll_no", "name", "average"]].to_string(index=False))

    print(f"\n=== Pass / Fail (pass mark = {PASS_MARK}) ===")
    print(df["status"].value_counts().to_string())

    print("\n=== Students with Maths >= 80 ===")
    print(df[df["maths"] >= 80][["name", "maths"]].to_string(index=False))

    print("\n=== Average by course ===")
    print(df.groupby("course")["average"].mean().round(2).to_string())

    print(f"\nStandard deviation of averages (NumPy): {np.std(df['average']):.2f}")
    return subject_avg, overall


def save_outputs(df, subject_avg, overall):
    OUTPUT_DIR.mkdir(exist_ok=True)
    processed = OUTPUT_DIR / "students_processed.csv"
    df.sort_values("average", ascending=False).to_csv(processed, index=False)

    summary = pd.DataFrame({
        "metric": (["total_students", "overall_average", "highest_average",
                    "lowest_average", "passed", "failed"]
                   + [f"average_{s}" for s in SUBJECTS]),
        "value": ([len(df), round(overall, 2), df["average"].max(), df["average"].min(),
                   int((df["status"] == "Pass").sum()), int((df["status"] == "Fail").sum())]
                  + [subject_avg[s] for s in SUBJECTS]),
    })
    summary_path = OUTPUT_DIR / "analysis_summary.csv"
    summary.to_csv(summary_path, index=False)
    print(f"\nSaved: {processed}\nSaved: {summary_path}")


def main():
    try:
        df = load_data()
    except FileNotFoundError:
        print("students.csv not found next to this script.")
        return
    explore(df)
    missing_report(df)
    df = add_calculations(df)
    subject_avg, overall = analyse(df)
    save_outputs(df, subject_avg, overall)


if __name__ == "__main__":
    main()
