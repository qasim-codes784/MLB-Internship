"""
Day 2 launcher.   Run from the Day2 folder:   python main.py
Pick a project or lesson from a simple menu.
"""
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent

CHOICES = {
    "1": ("Student Record Management System v2", "Student_Record_Management/main.py"),
    "2": ("Student Performance Analysis", "Student_Performance_Analysis/main.py"),
    "3": ("Lesson 1: File Handling", "lessons/01_file_handling.py"),
    "4": ("Lesson 2: JSON", "lessons/02_json_basics.py"),
    "5": ("Lesson 3: NumPy", "lessons/03_numpy_fundamentals.py"),
    "6": ("Lesson 4: Pandas", "lessons/04_pandas_basics.py"),
    "7": ("Practice 1: File Handling", "practice/01_file_handling_exercises.py"),
    "8": ("Practice 2: JSON", "practice/02_json_exercises.py"),
    "9": ("Practice 3: NumPy", "practice/03_numpy_exercises.py"),
    "10": ("Practice 4: Pandas", "practice/04_pandas_exercises.py"),
}


def main():
    while True:
        print("\n===== Day 2 - Files, JSON, NumPy & Pandas =====")
        for key, (title, _) in CHOICES.items():
            print(f"{key}. {title}")
        print("0. Exit")
        try:
            choice = input("Choose: ").strip()
        except (EOFError, KeyboardInterrupt):
            break
        if choice == "0":
            break
        if choice in CHOICES:
            # Run each script in its own process using the same Python.
            subprocess.run([sys.executable, str(ROOT / CHOICES[choice][1])], cwd=ROOT)
        else:
            print("Invalid choice.")
    print("Goodbye!")


if __name__ == "__main__":
    main()
