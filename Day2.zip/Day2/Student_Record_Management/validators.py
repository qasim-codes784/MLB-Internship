"""
validators.py - input checking for the Student Record Management System (v2).

Every function takes a raw value (usually text typed by the user),
returns a CLEAN value, or raises ValueError with a friendly message.
Keeping validation separate from the menu makes it easy to test.
"""


def validate_roll_no(value):
    """Roll number must be a whole number from 1 to 999999 (same rule as Day 1)."""
    text = str(value).strip()
    if not text.isdigit():
        raise ValueError("Roll number must be a whole number.")
    number = int(text)
    if not 1 <= number <= 999999:
        raise ValueError("Roll number must be between 1 and 999999.")
    return number


def validate_name(value):
    """Name must contain letters and spaces only (same rule as Day 1)."""
    text = " ".join(str(value).split())  # trims and removes double spaces
    if not text:
        raise ValueError("Name cannot be empty.")
    if not text.replace(" ", "").isalpha():
        raise ValueError("Name should contain letters only.")
    return text


def validate_age(value):
    """Age must be a whole number from 5 to 100 (same rule as Day 1)."""
    text = str(value).strip()
    if not text.isdigit():
        raise ValueError("Age must be a whole number.")
    age = int(text)
    if not 5 <= age <= 100:
        raise ValueError("Age must be between 5 and 100.")
    return age


def validate_course(value):
    """Course cannot be empty."""
    text = " ".join(str(value).split())
    if not text:
        raise ValueError("Course cannot be empty.")
    return text


def validate_subject(value):
    """Subject is OPTIONAL. A blank value is allowed and becomes ''."""
    if value is None:
        return ""
    return " ".join(str(value).split())


def validate_marks(value):
    """Marks are OPTIONAL (0-100). Blank/None means 'no marks yet' -> None."""
    if value is None or str(value).strip() == "":
        return None
    try:
        marks = float(str(value).strip())
    except ValueError:
        raise ValueError("Marks must be a number.")
    if not 0 <= marks <= 100:
        raise ValueError("Marks must be between 0 and 100.")
    return int(marks) if marks.is_integer() else marks


# Maps each field name to its validator, so other code can loop over them.
FIELD_VALIDATORS = {
    "roll_no": validate_roll_no,
    "name": validate_name,
    "age": validate_age,
    "course": validate_course,
    "subject": validate_subject,
    "marks": validate_marks,
}


def validate_student(data):
    """Validate a whole student dictionary and return a cleaned copy."""
    for required in ("roll_no", "name", "age", "course"):
        if required not in data:
            raise ValueError(f"Missing required field: {required}")
    return {
        field: check(data.get(field))
        for field, check in FIELD_VALIDATORS.items()
    }
