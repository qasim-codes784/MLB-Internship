"""
student_manager.py - the "brain" of the system (no input() or print() here).

StudentManager keeps the list of students in memory AND saves to JSON after
every change, so nothing is lost when the program closes.
"""
from pathlib import Path

import storage
import validators


class StudentManager:
    def __init__(self, data_file=storage.STUDENTS_FILE, backup_file=storage.BACKUP_FILE):
        self.data_file = Path(data_file)
        self.backup_file = Path(backup_file)
        # Load existing records automatically when the program starts.
        self.students = storage.load_students(self.data_file)

    # ---------- helpers ----------
    def save(self):
        storage.save_students(self.students, self.data_file)

    def find_by_roll(self, roll_no):
        """Return the student dict with this roll number, or None."""
        for student in self.students:
            if student.get("roll_no") == roll_no:
                return student
        return None

    # ---------- main features ----------
    def add_student(self, roll_no, name, age, course, subject="", marks=None):
        record = validators.validate_student({
            "roll_no": roll_no, "name": name, "age": age,
            "course": course, "subject": subject, "marks": marks,
        })
        if self.find_by_roll(record["roll_no"]):
            raise ValueError("A student with this roll number already exists.")
        self.students.append(record)
        self.save()  # automatic save
        return record

    def search_by_name(self, keyword):
        """Case-insensitive partial match, like Day 1."""
        keyword = str(keyword).strip().lower()
        return [s for s in self.students if keyword in s["name"].lower()]

    def update_student(self, roll_number, **changes):
        """Update only the fields given, e.g. update_student(5, age=21).
        The roll number itself cannot be changed (it is the unique ID)."""
        student = self.find_by_roll(roll_number)
        if student is None:
            raise KeyError("Student not found.")
        cleaned = {}
        for field, value in changes.items():
            if field == "roll_no" or field not in validators.FIELD_VALIDATORS:
                raise ValueError(f"Field '{field}' cannot be updated.")
            cleaned[field] = validators.FIELD_VALIDATORS[field](value)  # validate first
        student.update(cleaned)  # only changed after ALL values passed
        self.save()
        return student

    def delete_student(self, roll_no):
        student = self.find_by_roll(roll_no)
        if student is None:
            raise KeyError("Student not found.")
        self.create_backup()  # safety net before removing data
        self.students.remove(student)
        self.save()
        return student

    def total_students(self):
        return len(self.students)

    def create_backup(self):
        self.save()  # make sure the file is up to date first
        return storage.backup_students(self.data_file, self.backup_file)

    def export_csv(self, csv_path):
        return storage.export_to_csv(self.students, csv_path)

    def statistics(self):
        """Summary numbers for the 'Student Statistics' menu option."""
        stats = {"total": len(self.students), "average_age": None,
                 "youngest": None, "oldest": None,
                 "per_course": {}, "with_marks": 0, "average_marks": None}
        if not self.students:
            return stats
        ages = [s["age"] for s in self.students]
        stats["average_age"] = round(sum(ages) / len(ages), 2)
        stats["youngest"] = min(self.students, key=lambda s: s["age"])
        stats["oldest"] = max(self.students, key=lambda s: s["age"])
        for student in self.students:
            course = student["course"]
            stats["per_course"][course] = stats["per_course"].get(course, 0) + 1
        marks = [s["marks"] for s in self.students if s.get("marks") is not None]
        stats["with_marks"] = len(marks)
        if marks:
            stats["average_marks"] = round(sum(marks) / len(marks), 2)
        return stats
