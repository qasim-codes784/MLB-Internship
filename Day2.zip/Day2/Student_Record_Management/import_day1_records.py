"""
import_day1_records.py - OPTIONAL migration helper.

Day 1 stored students only in the program's memory, so they were lost when
it closed. Nothing can be recovered automatically. If you have your old
students written down (or in a CSV), put them in a CSV file with this header:

    roll_no,name,age,course

then run (from the Day2 folder):

    python Student_Record_Management/import_day1_records.py my_old_students.csv

A backup of students.json is made first. Duplicate roll numbers and invalid
rows are skipped and reported - nothing existing is overwritten.
"""
import csv
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from student_manager import StudentManager


def import_from_csv(csv_path, manager):
    """Import rows from csv_path into the manager. Returns (added, skipped)."""
    manager.create_backup()  # backup BEFORE changing anything
    added, skipped = 0, []
    with open(csv_path, "r", newline="", encoding="utf-8-sig") as file:
        for line_no, row in enumerate(csv.DictReader(file), start=2):
            try:
                manager.add_student(row.get("roll_no"), row.get("name"),
                                    row.get("age"), row.get("course"),
                                    row.get("subject", ""), row.get("marks"))
                added += 1
            except ValueError as error:
                skipped.append((line_no, str(error)))
    return added, skipped


def main():
    if len(sys.argv) != 2:
        print("Usage: python Student_Record_Management/import_day1_records.py <file.csv>")
        return
    csv_path = Path(sys.argv[1])
    try:
        added, skipped = import_from_csv(csv_path, StudentManager())
    except FileNotFoundError:
        print(f"File not found: {csv_path}")
        return
    print(f"Imported {added} student(s).")
    for line_no, reason in skipped:
        print(f"  Skipped line {line_no}: {reason}")


if __name__ == "__main__":
    main()
