"""
storage.py - everything that touches files (JSON and CSV).

Day 1 kept students in a Python list, so they vanished when the program
closed. Here we save them to a JSON file and load them again at start-up.
"""
import csv
import json
import os
import shutil
from datetime import datetime
from pathlib import Path

# pathlib builds paths that work on Windows, macOS and Linux.
DATA_DIR = Path(__file__).resolve().parent / "data"
STUDENTS_FILE = DATA_DIR / "students.json"
BACKUP_FILE = DATA_DIR / "students_backup.json"

CSV_FIELDS = ["roll_no", "name", "age", "course", "subject", "marks"]


def save_students(students, path=STUDENTS_FILE):
    """Write the list of students to a JSON file safely.

    We write to a temporary file first and then replace the real file.
    If the program crashes mid-write, the old file is still intact.
    """
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp_path = path.with_suffix(".tmp")
    with open(temp_path, "w", encoding="utf-8") as file:  # "w" = write mode
        json.dump(students, file, indent=4, ensure_ascii=False)
    os.replace(temp_path, path)


def _keep_corrupt_copy(path):
    """Copy an unreadable file aside so the user's data is never destroyed."""
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    copy_path = path.with_name(f"{path.stem}_corrupt_{stamp}.json")
    shutil.copy2(path, copy_path)
    return copy_path


def load_students(path=STUDENTS_FILE):
    """Load students from JSON. Always returns a list.

    - Missing file   -> create an empty one and return [].
    - Empty file     -> return [].
    - Malformed JSON -> keep a copy of the bad file, warn, return [].
    """
    path = Path(path)
    if not path.exists():
        save_students([], path)
        return []
    if path.stat().st_size == 0:
        return []
    try:
        with open(path, "r", encoding="utf-8") as file:  # "r" = read mode
            data = json.load(file)
        if not isinstance(data, list):
            raise ValueError("JSON root must be a list of students.")
        return data
    except (json.JSONDecodeError, ValueError):
        copy_path = _keep_corrupt_copy(path)
        print(f"WARNING: {path.name} is not valid student JSON.")
        print(f"         A copy was kept as {copy_path.name}. Starting empty.")
        return []


def backup_students(path=STUDENTS_FILE, backup_path=BACKUP_FILE):
    """Copy the data file to the backup file. Returns True if a backup was made."""
    path = Path(path)
    if not path.exists():
        return False
    Path(backup_path).parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(path, backup_path)
    return True


def export_to_csv(students, csv_path):
    """Write students to a CSV file (opens fine in Excel)."""
    csv_path = Path(csv_path)
    csv_path.parent.mkdir(parents=True, exist_ok=True)
    # utf-8-sig = UTF-8 plus a marker so Excel shows non-English names correctly.
    with open(csv_path, "w", newline="", encoding="utf-8-sig") as file:
        writer = csv.DictWriter(file, fieldnames=CSV_FIELDS, extrasaction="ignore")
        writer.writeheader()
        for student in students:
            row = dict(student)
            if row.get("marks") is None:
                row["marks"] = ""  # blank cell instead of the word "None"
            writer.writerow(row)
    return csv_path
