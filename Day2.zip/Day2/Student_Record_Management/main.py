"""
Student Record Management System - VERSION 2 (JSON storage)

Run from the Day2 folder:   python Student_Record_Management/main.py
Same menu style as Day 1, but records are now saved permanently.
"""
import sys
from pathlib import Path

# Let Python find the sibling modules no matter where we run from.
sys.path.insert(0, str(Path(__file__).resolve().parent))

import validators
from student_manager import StudentManager

OUTPUT_DIR = Path(__file__).resolve().parent.parent / "outputs"


def ask(prompt, validator, optional=False):
    """Keep asking until the validator accepts the answer."""
    while True:
        answer = input(prompt).strip()
        if optional and answer == "":
            return validator(answer)
        try:
            return validator(answer)
        except ValueError as error:
            print(f"  Invalid input: {error}")


def print_student(student):
    line = (f"  Roll No: {student['roll_no']} | Name: {student['name']} | "
            f"Age: {student['age']} | Course: {student['course']}")
    if student.get("subject") or student.get("marks") is not None:
        line += f" | Subject: {student.get('subject') or '-'} | Marks: {student.get('marks')}"
    print(line)


def add_student(manager):
    print("\n--- Add Student ---")
    roll_no = ask("Roll number: ", validators.validate_roll_no)
    if manager.find_by_roll(roll_no):
        print("A student with this roll number already exists.")
        return
    name = ask("Name: ", validators.validate_name)
    age = ask("Age (5-100): ", validators.validate_age)
    course = ask("Course: ", validators.validate_course)
    subject = ask("Subject (optional, Enter to skip): ", validators.validate_subject, optional=True)
    marks = ask("Marks 0-100 (optional, Enter to skip): ", validators.validate_marks, optional=True)
    manager.add_student(roll_no, name, age, course, subject, marks)
    print("Student added and saved successfully.")


def view_students(manager):
    print("\n--- All Students ---")
    if not manager.students:
        print("No students found.")
        return
    for student in manager.students:
        print_student(student)
    print("Total students:", manager.total_students())


def search_by_roll(manager):
    print("\n--- Search by Roll Number ---")
    student = manager.find_by_roll(ask("Roll number: ", validators.validate_roll_no))
    print_student(student) if student else print("Student not found.")


def search_by_name(manager):
    print("\n--- Search by Name ---")
    keyword = input("Name (or part of it): ").strip()
    if not keyword:
        print("Please type something to search for.")
        return
    found = manager.search_by_name(keyword)
    if found:
        for student in found:
            print_student(student)
    else:
        print("Student not found.")


def update_student(manager):
    print("\n--- Update Student ---")
    roll_no = ask("Roll number of student to update: ", validators.validate_roll_no)
    student = manager.find_by_roll(roll_no)
    if not student:
        print("Student not found.")
        return
    print("Current record:")
    print_student(student)
    print("Press Enter to keep the current value.")
    changes = {}
    for field, label, check in [
        ("name", "New name: ", validators.validate_name),
        ("age", "New age: ", validators.validate_age),
        ("course", "New course: ", validators.validate_course),
        ("subject", "New subject: ", validators.validate_subject),
        ("marks", "New marks: ", validators.validate_marks),
    ]:
        while True:
            answer = input(label).strip()
            if answer == "":
                break  # keep old value
            try:
                changes[field] = check(answer)
                break
            except ValueError as error:
                print(f"  Invalid input: {error}")
    if not changes:
        print("Nothing changed.")
        return
    manager.update_student(roll_no, **changes)
    print("Student updated and saved successfully.")


def delete_student(manager):
    print("\n--- Delete Student ---")
    roll_no = ask("Roll number of student to delete: ", validators.validate_roll_no)
    student = manager.find_by_roll(roll_no)
    if not student:
        print("Student not found.")
        return
    print_student(student)
    if input("Type YES to confirm deletion: ").strip().upper() != "YES":
        print("Deletion cancelled.")
        return
    manager.delete_student(roll_no)  # makes a backup first
    print("Student deleted (a backup was saved first).")


def show_statistics(manager):
    print("\n--- Student Statistics ---")
    stats = manager.statistics()
    print("Total students:", stats["total"])
    if stats["total"] == 0:
        print("No data yet.")
        return
    print("Average age:", stats["average_age"])
    print("Youngest:", stats["youngest"]["name"], f"({stats['youngest']['age']})")
    print("Oldest:", stats["oldest"]["name"], f"({stats['oldest']['age']})")
    print("Students per course:")
    for course, count in stats["per_course"].items():
        print(f"  {course}: {count}")
    if stats["with_marks"]:
        print(f"Average marks ({stats['with_marks']} students with marks):", stats["average_marks"])
    else:
        print("No marks recorded yet.")


def export_csv(manager):
    path = manager.export_csv(OUTPUT_DIR / "students_export.csv")
    print(f"Exported {manager.total_students()} students to {path}")


def show_menu():
    print("\n===== Student Record Management System v2 =====")
    print("1. Add Student")
    print("2. View All Students")
    print("3. Search by Roll Number")
    print("4. Search by Name")
    print("5. Update Student")
    print("6. Delete Student")
    print("7. Total Number of Students")
    print("8. Student Statistics")
    print("9. Create JSON Backup")
    print("10. Export to CSV")
    print("11. Exit")


def main():
    manager = StudentManager()  # loads students.json automatically
    print(f"Loaded {manager.total_students()} student(s) from {manager.data_file.name}.")
    actions = {
        "1": add_student, "2": view_students, "3": search_by_roll,
        "4": search_by_name, "5": update_student, "6": delete_student,
        "7": lambda m: print("Total students:", m.total_students()),
        "8": show_statistics,
        "9": lambda m: print("Backup created." if m.create_backup() else "Nothing to back up."),
        "10": export_csv,
    }
    try:
        while True:
            show_menu()
            choice = input("Enter your choice (1-11): ").strip()
            if choice == "11":
                print("Goodbye! All changes are already saved.")
                break
            action = actions.get(choice)
            if action is None:
                print("Invalid choice, please enter a number from 1 to 11.")
                continue
            try:
                action(manager)
            except (ValueError, KeyError, OSError) as error:
                print(f"Error: {error}")
    except (KeyboardInterrupt, EOFError):
        print("\nProgram closed. All saved changes are safe.")

    print("-----------------------")
    print("Written by: Syed M Qasim Bukhari")


if __name__ == "__main__":
    main()
