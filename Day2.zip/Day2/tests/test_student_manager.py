"""
Tests for Student Record Management v2.
Every test uses a TEMPORARY folder, so real data is never touched.
Run from the Day2 folder:  python -m unittest discover -s tests -v
"""
import csv
import json
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "Student_Record_Management"))

import storage
import validators
from import_day1_records import import_from_csv
from student_manager import StudentManager


class BaseTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.dir = Path(self.tmp.name)
        self.data_file = self.dir / "students.json"
        self.backup_file = self.dir / "backup.json"
        self.manager = self.new_manager()

    def tearDown(self):
        self.tmp.cleanup()

    def new_manager(self):
        return StudentManager(self.data_file, self.backup_file)


class TestManager(BaseTest):
    def test_add_and_search_by_roll(self):
        self.manager.add_student(1, "Ali Khan", 20, "Data Science")
        self.assertEqual(self.manager.find_by_roll(1)["name"], "Ali Khan")
        self.assertIsNone(self.manager.find_by_roll(99))

    def test_search_by_name_partial_case_insensitive(self):
        self.manager.add_student(1, "Ali Khan", 20, "DS")
        self.manager.add_student(2, "Sara Ahmed", 21, "DS")
        self.assertEqual(len(self.manager.search_by_name("KHAN")), 1)
        self.assertEqual(self.manager.search_by_name("zzz"), [])

    def test_duplicate_roll_rejected(self):
        self.manager.add_student(1, "Ali Khan", 20, "DS")
        with self.assertRaises(ValueError):
            self.manager.add_student(1, "Other Person", 22, "AI")
        self.assertEqual(self.manager.total_students(), 1)

    def test_update(self):
        self.manager.add_student(1, "Ali Khan", 20, "DS")
        self.manager.update_student(1, age=21, course="AI")
        student = self.manager.find_by_roll(1)
        self.assertEqual((student["age"], student["course"]), (21, "AI"))

    def test_update_invalid_changes_nothing(self):
        self.manager.add_student(1, "Ali Khan", 20, "DS")
        with self.assertRaises(ValueError):
            self.manager.update_student(1, age=22, name="Bad123")
        self.assertEqual(self.manager.find_by_roll(1)["age"], 20)

    def test_cannot_change_roll_or_update_missing(self):
        self.manager.add_student(1, "Ali Khan", 20, "DS")
        with self.assertRaises(ValueError):
            self.manager.update_student(1, roll_no=5)
        with self.assertRaises(KeyError):
            self.manager.update_student(77, age=20)

    def test_delete_and_backup(self):
        self.manager.add_student(1, "Ali Khan", 20, "DS")
        self.manager.delete_student(1)
        self.assertEqual(self.manager.total_students(), 0)
        # the backup was taken BEFORE deleting, so it still holds the student
        backup = json.loads(self.backup_file.read_text(encoding="utf-8"))
        self.assertEqual(len(backup), 1)
        with self.assertRaises(KeyError):
            self.manager.delete_student(1)

    def test_statistics(self):
        self.assertEqual(self.manager.statistics()["total"], 0)  # empty data ok
        self.manager.add_student(1, "Ali Khan", 20, "DS", "Math", 80)
        self.manager.add_student(2, "Sara Ahmed", 22, "DS")
        stats = self.manager.statistics()
        self.assertEqual(stats["average_age"], 21)
        self.assertEqual(stats["per_course"], {"DS": 2})
        self.assertEqual(stats["average_marks"], 80)


class TestPersistence(BaseTest):
    def test_data_survives_restart(self):
        self.manager.add_student(1, "Ali Khan", 20, "DS")
        self.manager.update_student(1, age=25)
        reopened = self.new_manager()  # simulates closing and reopening
        self.assertEqual(reopened.find_by_roll(1)["age"], 25)

    def test_missing_file_gives_empty_list_and_creates_file(self):
        self.assertEqual(self.manager.students, [])
        self.assertTrue(self.data_file.exists())

    def test_malformed_json_is_kept_and_handled(self):
        self.data_file.write_text("{ this is not json", encoding="utf-8")
        manager = self.new_manager()
        self.assertEqual(manager.students, [])
        corrupt = list(self.dir.glob("students_corrupt_*.json"))
        self.assertEqual(len(corrupt), 1)
        self.assertIn("not json", corrupt[0].read_text(encoding="utf-8"))

    def test_wrong_json_shape_handled(self):
        self.data_file.write_text('{"a": 1}', encoding="utf-8")
        self.assertEqual(self.new_manager().students, [])

    def test_empty_file_handled(self):
        self.data_file.write_text("", encoding="utf-8")
        self.assertEqual(self.new_manager().students, [])

    def test_utf8_names_roundtrip(self):
        self.manager.add_student(1, "Zoë Müller", 20, "DS")
        self.assertEqual(self.new_manager().find_by_roll(1)["name"], "Zoë Müller")


class TestExportAndImport(BaseTest):
    def test_csv_export(self):
        self.manager.add_student(1, "Ali Khan", 20, "DS", "Math", 75.5)
        self.manager.add_student(2, "Sara Ahmed", 21, "AI")
        out = self.manager.export_csv(self.dir / "out.csv")
        with open(out, newline="", encoding="utf-8-sig") as f:
            rows = list(csv.DictReader(f))
        self.assertEqual(len(rows), 2)
        self.assertEqual(rows[0]["marks"], "75.5")
        self.assertEqual(rows[1]["marks"], "")  # None exported as blank

    def test_import_skips_duplicates_and_bad_rows_and_backs_up(self):
        self.manager.add_student(1, "Ali Khan", 20, "DS")
        src = self.dir / "old.csv"
        src.write_text("roll_no,name,age,course\n1,Dup Person,20,DS\n"
                       "2,Sara Ahmed,21,AI\n3,Bad123,20,DS\n", encoding="utf-8")
        added, skipped = import_from_csv(src, self.manager)
        self.assertEqual(added, 1)
        self.assertEqual(len(skipped), 2)
        self.assertEqual(self.manager.find_by_roll(1)["name"], "Ali Khan")
        self.assertEqual(len(json.loads(self.backup_file.read_text(encoding="utf-8"))), 1)


class TestValidators(unittest.TestCase):
    def test_roll_no(self):
        self.assertEqual(validators.validate_roll_no(" 12 "), 12)
        for bad in ("abc", "0", "-3", "1000000", "", "1.5"):
            with self.assertRaises(ValueError):
                validators.validate_roll_no(bad)

    def test_name_age_course(self):
        self.assertEqual(validators.validate_name("  ali   khan "), "ali khan")
        for bad in ("", "R2D2"):
            with self.assertRaises(ValueError):
                validators.validate_name(bad)
        for bad in ("4", "101", "x"):
            with self.assertRaises(ValueError):
                validators.validate_age(bad)
        with self.assertRaises(ValueError):
            validators.validate_course("   ")

    def test_marks_optional(self):
        self.assertIsNone(validators.validate_marks(""))
        self.assertEqual(validators.validate_marks("85"), 85)
        self.assertEqual(validators.validate_marks("85.5"), 85.5)
        for bad in ("abc", "101", "-1"):
            with self.assertRaises(ValueError):
                validators.validate_marks(bad)


if __name__ == "__main__":
    unittest.main()
