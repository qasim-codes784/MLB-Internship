"""
PRACTICE 4 - Pandas (on the SAMPLE student dataset)
Try each TASK yourself first. Run:  python practice/04_pandas_exercises.py
"""
from pathlib import Path

import pandas as pd

CSV = Path(__file__).resolve().parent.parent / "Student_Performance_Analysis" / "students.csv"

# ============================== TASKS ==============================
# 1. Load the dataset.            2. Show first and last five rows.
# 3. Show dataset information.    4. Find missing values.
# 5. Filter students with maths >= 60.   6. Calculate summary statistics.

# ============================ SOLUTIONS ============================
df = pd.read_csv(CSV, comment="#")                                  # 1
print("First 5:\n", df.head(), "\n\nLast 5:\n", df.tail())          # 2
df.info()                                                            # 3
print("\nMissing values:\n", df.isnull().sum())                     # 4  Expected: science 1, english 1
print("\nMaths >= 60:\n", df[df["maths"] >= 60][["name", "maths"]])  # 5  Expected: 7 students
print("\nSummary:\n", df.describe().round(2))                        # 6

assert df.shape == (12, 6)
assert df["science"].isnull().sum() == 1 and df["english"].isnull().sum() == 1
assert len(df[df["maths"] >= 60]) == 7
print("\nAll checks passed.")
