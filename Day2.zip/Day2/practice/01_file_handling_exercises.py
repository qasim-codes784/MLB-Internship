"""
PRACTICE 1 - File Handling
HOW TO USE: Read each TASK, try to write it yourself first (in a new file),
then compare with the SOLUTION below. Run:  python practice/01_file_handling_exercises.py
"""
from pathlib import Path

OUT = Path(__file__).resolve().parent.parent / "outputs"
OUT.mkdir(exist_ok=True)
FILE = OUT / "practice_notes.txt"

# ============================== TASKS ==============================
# 1. Create a text file and write 3 lines of data into it.
# 2. Read the file and display its contents.
# 3. Append 2 more lines without erasing the old ones.
# 4. Count the number of lines in the file.
# 5. Bonus: handle the case where the file does not exist.

# ============================ SOLUTIONS ============================
def create_file(path, lines):
    with open(path, "w", encoding="utf-8") as file:
        for line in lines:
            file.write(line + "\n")

def read_file(path):
    with open(path, "r", encoding="utf-8") as file:
        return file.read()

def append_lines(path, lines):
    with open(path, "a", encoding="utf-8") as file:
        for line in lines:
            file.write(line + "\n")

def count_lines(path):
    try:
        with open(path, "r", encoding="utf-8") as file:
            return sum(1 for _ in file)
    except FileNotFoundError:
        print("File not found:", path.name)
        return 0


if __name__ == "__main__":
    create_file(FILE, ["Apple", "Banana", "Cherry"])
    print("Contents after create:\n" + read_file(FILE))
    append_lines(FILE, ["Date", "Elderberry"])
    print("Contents after append:\n" + read_file(FILE))
    print("Line count:", count_lines(FILE))            # Expected: 5
    print("Missing file count:", count_lines(OUT / "missing.txt"))  # Expected: message, then 0
