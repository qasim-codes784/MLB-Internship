"""
PRACTICE 2 - JSON
Try each TASK yourself first, then compare with the SOLUTIONS.
Run:  python practice/02_json_exercises.py
(Uses a practice file in outputs/ - your real student data is never touched.)
"""
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent.parent / "outputs"
OUT.mkdir(exist_ok=True)
FILE = OUT / "practice_students.json"

# ============================== TASKS ==============================
# 1. Store information for 3 students in a JSON file.
# 2. Read the data back from the file.
# 3. Update one existing student's information.
# 4. Add a new student (refuse duplicate roll numbers).
# 5. Convert a dictionary to a JSON string and back.

# ============================ SOLUTIONS ============================
def save(students, path=FILE):
    with open(path, "w", encoding="utf-8") as file:
        json.dump(students, file, indent=4)

def load(path=FILE):
    try:
        with open(path, "r", encoding="utf-8") as file:
            return json.load(file)
    except (FileNotFoundError, json.JSONDecodeError):
        return []

def update(students, roll_no, **changes):
    for student in students:
        if student["roll_no"] == roll_no:
            student.update(changes)
            return True
    return False

def add(students, new_student):
    if any(s["roll_no"] == new_student["roll_no"] for s in students):
        return False
    students.append(new_student)
    return True


if __name__ == "__main__":
    # Invented practice names - not real records.
    data = [
        {"roll_no": 1, "name": "Practice One", "age": 20, "course": "AI"},
        {"roll_no": 2, "name": "Practice Two", "age": 21, "course": "DS"},
        {"roll_no": 3, "name": "Practice Three", "age": 22, "course": "CV"},
    ]
    save(data)
    students = load()
    print("Loaded:", len(students))                               # Expected: 3
    print("Updated 2:", update(students, 2, age=30))              # Expected: True
    print("Updated 99:", update(students, 99, age=30))            # Expected: False
    print("Add new:", add(students, {"roll_no": 4, "name": "Practice Four", "age": 19, "course": "AI"}))  # True
    print("Add duplicate:", add(students, {"roll_no": 4, "name": "X", "age": 19, "course": "AI"}))         # False
    save(students)
    print("Saved total:", len(load()))                            # Expected: 4
    text = json.dumps(students[0])
    print("dict -> str:", text)
    print("str -> dict:", json.loads(text)["name"])               # Expected: Practice One
