"""
PRACTICE 3 - NumPy
Try each question yourself first. The expected answer is next to each one,
and the script checks the answers with assert (no error = correct).
Run:  python practice/03_numpy_exercises.py
"""
import numpy as np

a = np.array([4, 8, 15, 16, 23, 42])
m = np.arange(1, 13).reshape(3, 4)   # [[1..4],[5..8],[9..12]]

# ---- 10+ questions, each with its expected result ----
# Q1  Create a 1D array of 1..5.                       -> [1 2 3 4 5]
assert (np.array([1, 2, 3, 4, 5]) == np.arange(1, 6)).all()
# Q2  Create a 2D array with 2 rows, 3 columns of ones. -> shape (2, 3)
assert np.ones((2, 3)).shape == (2, 3)
# Q3  Add 10 to every element of a.                    -> [14 18 25 26 33 52]
assert (a + 10 == [14, 18, 25, 26, 33, 52]).all()
# Q4  Multiply a by 2.                                 -> [ 8 16 30 32 46 84]
assert (a * 2 == [8, 16, 30, 32, 46, 84]).all()
# Q5  Sum of a.                                        -> 108
assert a.sum() == 108
# Q6  Mean of a.                                       -> 18.0
assert a.mean() == 18.0
# Q7  Minimum and maximum of a.                        -> 4 and 42
assert (a.min(), a.max()) == (4, 42)
# Q8  Elements at index 1 to 3 of a (slice).           -> [ 8 15 16]
assert (a[1:4] == [8, 15, 16]).all()
# Q9  Last element of a.                               -> 42
assert a[-1] == 42
# Q10 Element in row 2, column 3 of m.                 -> 12
assert m[2, 3] == 12
# Q11 Second column of m.                              -> [ 2  6 10]
assert (m[:, 1] == [2, 6, 10]).all()
# Q12 Reshape m to 4 rows, 3 columns.                  -> shape (4, 3)
assert m.reshape(4, 3).shape == (4, 3)
# Q13 Reshape m into 1D.                               -> 12 elements
assert m.reshape(-1).size == 12
# Q14 Row sums of m.                                   -> [10 26 42]
assert (m.sum(axis=1) == [10, 26, 42]).all()
# Q15 Elements of a greater than 15.                   -> [16 23 42]
assert (a[a > 15] == [16, 23, 42]).all()
# Q16 Why does a.reshape(4, 2) fail? 6 elements cannot fill 4 x 2 = 8 slots.
try:
    a.reshape(4, 2)
    raise SystemExit("Q16 should have failed")
except ValueError:
    pass

print("All 16 NumPy practice answers are correct.")
print("a =", a, "| shape:", a.shape, "| dtype:", a.dtype)
print("m =\n", m, "\nmean of m:", m.mean())  # Expected mean: 6.5
