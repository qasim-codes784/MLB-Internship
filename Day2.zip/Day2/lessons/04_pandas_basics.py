"""
LESSON 4 - Pandas basics
Run from the Day2 folder:  python lessons/04_pandas_basics.py
Uses the SAMPLE dataset Student_Performance_Analysis/students.csv.
"""
from pathlib import Path

import pandas as pd

CSV = Path(__file__).resolve().parent.parent / "Student_Performance_Analysis" / "students.csv"

# 1. Series = one column (1D labelled data); DataFrame = whole table
series = pd.Series([85, 90, 78], index=["maths", "science", "english"])
print("Series:\n", series)

df = pd.read_csv(CSV, comment="#")   # comment="#" skips the note lines
print("\nDataFrame type:", type(df).__name__)

# 2. Inspect
print("\nhead(3):\n", df.head(3))
print("\ntail(2):\n", df.tail(2))
print("\nshape:", df.shape, "(rows, columns)")
print("columns:", list(df.columns))
df.info()
print(df.describe().round(2))

# 3. Selecting
print("\nOne column:\n", df["name"].head(3))
print("\nTwo columns:\n", df[["name", "maths"]].head(3))
print("\niloc[0] (first row by position):\n", df.iloc[0])
print("\nloc[2:4, ['name','maths']] (by label):\n", df.loc[2:4, ["name", "maths"]])

# 4. Filtering
print("\nMaths >= 80:\n", df[df["maths"] >= 80][["name", "maths"]])
print("\nAI AND maths > 90:\n", df[(df["course"] == "AI") & (df["maths"] > 90)][["name", "maths"]])

# 5. Missing values - LOOK before you change anything
print("\nMissing per column:\n", df.isnull().sum())
print("Rows with any missing value:\n", df[df.isnull().any(axis=1)][["roll_no", "name", "science", "english"]])
# Options: drop rows (loses students) or fill (invents numbers). We only
# demonstrate it on a COPY and keep the original untouched.
filled = df.copy()
filled["science"] = filled["science"].fillna(filled["science"].mean())
print("Science mean used to fill (demo copy only):", round(df["science"].mean(), 2))

# 6. Sorting and statistics
print("\nTop 3 by maths:\n", df.sort_values("maths", ascending=False)[["name", "maths"]].head(3))
print("\nMean per subject:\n", df[["maths", "science", "english"]].mean().round(2))
print("\nStudents per course:\n", df["course"].value_counts())
