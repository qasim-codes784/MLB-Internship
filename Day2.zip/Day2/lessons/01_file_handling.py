"""
LESSON 1 - File Handling
Run from the Day2 folder:  python lessons/01_file_handling.py
All files are created inside Day2/outputs/ only.
"""
from pathlib import Path

OUTPUT_DIR = Path(__file__).resolve().parent.parent / "outputs"
OUTPUT_DIR.mkdir(exist_ok=True)
notes = OUTPUT_DIR / "lesson_notes.txt"

# 1. WRITE mode "w": creates the file, or ERASES it if it already exists.
# `with` closes the file automatically, even if an error happens.
with open(notes, "w", encoding="utf-8") as file:
    file.write("Line 1: Hello from Python\n")
    file.write("Line 2: Files are easy\n")
print("1. Wrote the file with mode 'w'.")

# 2. READ mode "r": read everything as one string.
with open(notes, "r", encoding="utf-8") as file:
    content = file.read()
print("2. File content:\n" + content)
# Expected:
# Line 1: Hello from Python
# Line 2: Files are easy

# 3. APPEND mode "a": adds to the END without erasing.
with open(notes, "a", encoding="utf-8") as file:
    file.write("Line 3: Appended later\n")
print("3. Appended a line.")

# 4. Read line by line and count lines.
line_count = 0
with open(notes, "r", encoding="utf-8") as file:
    for line in file:  # a file is iterable: one line per loop
        line_count += 1
        print(f"   {line_count}: {line.rstrip()}")
print("4. Number of lines:", line_count)  # Expected: 3

# 5. Other read methods
with open(notes, "r", encoding="utf-8") as file:
    print("5. readline():", repr(file.readline()))   # just the first line
    print("   readlines():", len(file.readlines()), "remaining lines")  # Expected: 2

# 6. Manual open/close (what `with` does for you). Prefer `with`.
file = open(notes, "r", encoding="utf-8")
try:
    print("6. Manual open, first 6 chars:", file.read(6))  # Expected: Line 1
finally:
    file.close()
print("   Closed?", file.closed)  # Expected: True

# 7. Handling errors
try:
    with open(OUTPUT_DIR / "does_not_exist.txt", "r", encoding="utf-8") as file:
        file.read()
except FileNotFoundError:
    print("7. FileNotFoundError caught: that file does not exist.")
except PermissionError:
    print("7. No permission to open the file.")
except OSError as error:
    print("7. Other file problem:", error)
