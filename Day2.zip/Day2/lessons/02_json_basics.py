"""
LESSON 2 - JSON basics
Run from the Day2 folder:  python lessons/02_json_basics.py

JSON = text format for storing data. Looks like Python dicts/lists:
  Python dict -> JSON object   Python list -> JSON array
  str -> string   int/float -> number   True/False -> true/false   None -> null
"""
import json
from pathlib import Path

OUTPUT_DIR = Path(__file__).resolve().parent.parent / "outputs"
OUTPUT_DIR.mkdir(exist_ok=True)
json_file = OUTPUT_DIR / "lesson_students.json"

student = {"roll_no": 1, "name": "Demo Student", "age": 20, "course": "AI", "passed": True, "marks": None}

# 1. dumps = dump to String: Python object -> JSON text
text = json.dumps(student, indent=4)
print("1. json.dumps:\n" + text)
print("   type:", type(text).__name__)  # str

# 2. loads = load from String: JSON text -> Python object
back = json.loads(text)
print("2. json.loads ->", back, "| type:", type(back).__name__)  # dict
print("   True/None came back as:", back["passed"], back["marks"])

# 3. dump = write Python object to a FILE
students = [student, {"roll_no": 2, "name": "Second Demo", "age": 22, "course": "DS", "passed": False, "marks": 40}]
with open(json_file, "w", encoding="utf-8") as file:
    json.dump(students, file, indent=4, ensure_ascii=False)
print("3. json.dump wrote", len(students), "students to", json_file.name)

# 4. load = read a FILE into Python
with open(json_file, "r", encoding="utf-8") as file:
    loaded = json.load(file)
print("4. json.load read", len(loaded), "students")

# 5. Update an existing student
for item in loaded:
    if item["roll_no"] == 2:
        item["age"] = 23
        print("5. Updated student 2's age to 23")

# 6. Add a new student (check for duplicate roll number first!)
new = {"roll_no": 3, "name": "Third Demo", "age": 21, "course": "CV", "passed": True, "marks": 88}
if any(item["roll_no"] == new["roll_no"] for item in loaded):
    print("6. Duplicate roll number - not added")
else:
    loaded.append(new)
    print("6. Added student 3")

with open(json_file, "w", encoding="utf-8") as file:
    json.dump(loaded, file, indent=4)

# 7. Handle missing and broken files
def safe_load(path):
    try:
        with open(path, "r", encoding="utf-8") as file:
            return json.load(file)
    except FileNotFoundError:
        print("   File missing -> using empty list")
    except json.JSONDecodeError as error:
        print("   File is not valid JSON ->", error.msg)
    return []

print("7. Missing file:")
safe_load(OUTPUT_DIR / "nope.json")
broken = OUTPUT_DIR / "lesson_broken.json"
broken.write_text("{ not valid json", encoding="utf-8")
print("   Broken file:")
safe_load(broken)
broken.unlink()  # delete the demo file we made
print("Final saved file has", len(safe_load(json_file)), "students")  # Expected: 3
