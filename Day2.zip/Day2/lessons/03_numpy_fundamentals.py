"""
LESSON 3 - NumPy fundamentals
Run from the Day2 folder:  python lessons/03_numpy_fundamentals.py
NumPy arrays are fast, fixed-type grids of numbers; maths applies to every element at once.
"""
import numpy as np

# 1. Creating arrays
a = np.array([10, 20, 30, 40, 50])          # 1D
m = np.array([[1, 2, 3], [4, 5, 6]])        # 2D (2 rows, 3 columns)
print("1D:", a)
print("2D:\n", m)
print("zeros:", np.zeros(3), "| ones:", np.ones(2), "| arange:", np.arange(0, 10, 2))

# 2. Properties
print("\nshape:", m.shape)   # (2, 3)
print("ndim :", m.ndim)      # 2
print("size :", m.size)      # 6 (total elements)
print("dtype:", m.dtype)     # int64 (can differ by system)

# 3. Indexing and slicing (counting starts at 0)
print("\na[0] =", a[0], "| a[-1] =", a[-1])   # 10, 50
print("a[1:4] =", a[1:4])                      # [20 30 40] (end excluded)
print("m[1, 2] =", m[1, 2])                    # 6  (row 1, column 2)
print("m[0] =", m[0], "| m[:, 1] =", m[:, 1])  # first row | second column [2 5]

# 4. Element-wise arithmetic
b = np.array([1, 2, 3, 4, 5])
print("\na + b =", a + b)    # [11 22 33 44 55]
print("a - b =", a - b)
print("a * b =", a * b)      # [ 10  40  90 160 250]
print("a / b =", a / b)      # [10. 10. 10. 10. 10.]
print("a * 2 =", a * 2)      # a single number is applied to every element

# 5. Aggregations
print("\nsum :", a.sum())    # 150
print("mean:", a.mean())     # 30.0
print("min :", a.min(), "| max:", a.max())  # 10 | 50
print("column sums of m:", m.sum(axis=0))   # [5 7 9]
print("row sums of m   :", m.sum(axis=1))   # [ 6 15]

# 6. Mathematical functions
print("\nsqrt:", np.sqrt(np.array([1, 4, 9, 16])))  # [1. 2. 3. 4.]
print("power:", np.power(b, 2))                      # [ 1  4  9 16 25]
print("std  :", round(np.std(a), 2), "| median:", np.median(a))

# 7. Reshape: new shape must contain the SAME number of elements
r = np.arange(1, 13)            # 12 elements
print("\n12 -> (3, 4):\n", r.reshape(3, 4))
print("12 -> (2, 6):\n", r.reshape(2, 6))
print("-1 lets NumPy work it out:", r.reshape(4, -1).shape)  # (4, 3)
try:
    r.reshape(5, 3)  # 15 != 12
except ValueError as error:
    print("reshape(5, 3) fails ->", error)

# 8. Boolean filtering
print("\nvalues > 25:", a[a > 25])  # [30 40 50]
